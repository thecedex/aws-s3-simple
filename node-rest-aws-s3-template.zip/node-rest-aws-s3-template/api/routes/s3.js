const express = require('express');
const router = express.Router();
const multer = require('multer');
const upload = multer({dest: 'uploads/'});
const fs = require('fs');
const AWS = require('aws-sdk');
const xlsMimeType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
const pdfMimeType = 'application/pdf';

  // begin of API Key Authentication  
const matchesApiKey = (authorizationHeader) => {
  const clientKey = (authorizationHeader || '').replace('ApiKey ', '');
  return clientKey === process.env.API_KEY;
  }


const getFile = (body, fileExtension) => {
  const dateToken = body.billingDate.split("-");
  const year = dateToken[0];
  const month = dateToken[1];
  const day = dateToken[2];  
  const billDate = year + month + day;
  const fileName = billDate + '_' + body.invoiceNo + fileExtension;
  var filePath = body.platform + '/' +
                 body.backEnd + '/' +
                 year + '/' + 
                 month + '/'; 
  const formatRequestJson = {
        filePath : filePath,
        fileName : fileName
  }
  return formatRequestJson;
}

router.get('/', (req, res, next) => {
    res.status(200).json({ message : "it works but nothing happend" } );    
    return;
})

router.post('/', upload.single('file'),(req, res, next) => {

 
    if (!matchesApiKey(req.headers.api_key)) {
        res.status(403).json({
           error: 'Forbidden'
        });
        return;
    }    

    AWS.config.update({ accessKeyId: process.env.ACCESS_KEY_ID, 
      secretAccessKey: process.env.ACCESS_SECRET_KEY
   });

   // validations
   if (!req.body.filePath ){
       res.status(406).json({ error: 'No File Path' });  
       return;
   }else if( !process.env.BUCKET_NAME ){
      res.status(406).json({ error: 'Bucket could not be determined' }); 
      return; 
   } else if( !req.file ){ // must have a file
      res.status(406).json({ error: 'No file found' }); 
      return;    
   }else if ( req.file.mimetype !== pdfMimeType && req.file.mimetype !== xlsMimeType){
     // check file if it is excel or pdf 
//      res.status(406).json({ error: 'File must be an excel file or pdf file' });  
//      return;        
   } 

   var filePathLast = req.body.filePath[req.body.filePath.length - 1 ];
   if (filePathLast !== '/'){
     var key = req.body.filePath + '/' + req.file.originalname;
   } else{
      key = req.body.filePath + req.file.originalname;   
   }

   const s3 = new AWS.S3();
   var getParams = {
     Bucket: process.env.BUCKET_NAME,
     Key: key,
     Body : fs.createReadStream(req.file.path) 
   }
    
    AWS.config.update({ accessKeyId: process.env.ACCESS_KEY_ID, 
        secretAccessKey: process.env.ACCESS_SECRET_KEY
      });

    s3.upload(getParams, (err, data) => {
      if (err) {
        res.status(406).json({ error: err.code + ' ' + err.message });  
        return;
    } else { 
      res.status(200).json({ result: data.Location });
      return;
      }
    });    

})

router.get('/:platform/:backEnd/:billingDate/:invoiceNo', (req, res, next) => {

    if (!matchesApiKey(req.headers.api_key)) {
        res.status(403).json({
           error: 'Forbidden'
        });
        return;
    }

    if(!process.env.BUCKET_NAME){   // check for bucket
         res.status(406).json({ error: 'Bucket could not be determined' }); 
          return; 
    }

    const bucketName = process.env.BUCKET_NAME;
    const fileData = getFile( req.params, '.pdf');

    AWS.config.update({ accessKeyId: process.env.ACCESS_KEY_ID, 
      secretAccessKey: process.env.ACCESS_SECRET_KEY
       });

    const s3 = new AWS.S3();
    var getParams = {
            Bucket: bucketName, // your bucket name,
            Key: fileData.filePath + fileData.fileName
         }
                        
    s3.getObject(getParams, function(err, data) {
        // Handle any error and exit
         if (err){
            res.status(406).json( { error : err } );
            return err;            
         } else {


             // Convert Body from a Buffer to a String
             const base64dataBody = data.Body.toString('base64');             
             const fileSize = data.ContentLength;
             const resultJson = { bucket : bucketName,
                                  filePath : fileData.filePath,
                                  fileName : fileData.fileName,
                                  fileSize : fileSize,
                                  fileType : "pdf",
                                  fileContent : base64dataBody
                             };

             res.status(200).json({ result : resultJson }); 
            

            return;
         }    
        });
        
})



module.exports = router;